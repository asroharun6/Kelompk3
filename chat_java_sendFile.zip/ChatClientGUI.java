import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Arrays;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ChatClientGUI {
    private JFrame frame = new JFrame("Chat Client");
    private JTextField textField = new JTextField(40);
    private JTextArea messageArea = new JTextArea(16, 50);
    private JList<String> userList = new JList<>();
    private DefaultListModel<String> listModel = new DefaultListModel<>();
    private JButton sendFileButton = new JButton("Send File");
    private JFileChooser fileChooser = new JFileChooser();

    private BufferedReader in;
    private PrintWriter out;
    private Socket socket;

    public ChatClientGUI(String serverAddress) throws IOException {
        // Setup GUI components
        textField.setEditable(false);
        messageArea.setEditable(false);
        userList.setModel(listModel);

        frame.getContentPane().add(new JScrollPane(messageArea), BorderLayout.CENTER);
        frame.getContentPane().add(textField, BorderLayout.SOUTH);
        frame.getContentPane().add(new JScrollPane(userList), BorderLayout.EAST);

        JPanel southPanel = new JPanel(new FlowLayout());
        southPanel.add(textField);
        southPanel.add(sendFileButton);
        frame.getContentPane().add(southPanel, BorderLayout.SOUTH);

        frame.pack();

        setupFileChooser();

        sendFileButton.addActionListener(e -> {
            int result = fileChooser.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                File fileToSend = fileChooser.getSelectedFile();
                sendFile(fileToSend);
            }
        });

        textField.addActionListener(e -> {
            out.println("MESSAGE " + textField.getText());
            textField.setText("");
        });

        socket = new Socket(serverAddress, 1234);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        Thread listenerThread = new Thread(() -> {
            try {
                while (true) {
                    String line = in.readLine();
                    if (line.startsWith("SUBMITNAME")) {
                        String name = JOptionPane.showInputDialog(
                            frame,
                            "Choose a screen name:",
                            "Screen name selection",
                            JOptionPane.PLAIN_MESSAGE);
                        out.println(name);
                    } else if (line.startsWith("SUBMITNIM")) {
                        String nim = JOptionPane.showInputDialog(
                            frame,
                            "Enter your NIM:",
                            "NIM Entry",
                            JOptionPane.PLAIN_MESSAGE);
                        out.println(nim);
                    } else if (line.startsWith("NAMEACCEPTED")) {
                        textField.setEditable(true);
                    } else if (line.startsWith("MESSAGE")) {
                        messageArea.append(line.substring(8) + "\n");
                    } else if (line.startsWith("USERLIST")) {
                        String[] userArray = line.substring(9).split(",");
                        listModel.removeAllElements();
                        Arrays.asList(userArray).forEach(listModel::addElement);
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        listenerThread.start();
    }

    private void setupFileChooser() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG, JPEG, PDF Files", "jpg", "jpeg", "pdf");
        fileChooser.setFileFilter(filter);
    }

    private void sendFile(File file) {
        try {
            byte[] fileBytes = Files.readAllBytes(file.toPath());
            out.println("FILE " + file.getName() + " " + file.length());
            socket.getOutputStream().write(fileBytes, 0, fileBytes.length);
            socket.getOutputStream().flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        ChatClientGUI client = new ChatClientGUI("localhost"); // Replace with the correct server address
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.frame.setVisible(true);
    }
}
