import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ChatServer {
    private int port;
    private Set<ClientHandler> clientHandlers = Collections.synchronizedSet(new HashSet<>());

    public ChatServer(int port) {
        this.port = port;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Chat Server is running on port " + port);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(clientSocket);
                clientHandlers.add(handler);
                handler.start();
            }
        } catch (IOException e) {
            System.out.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private class ClientHandler extends Thread {
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private String name;
        private String nim;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                requestUserInfo();

                String line;
                while ((line = in.readLine()) != null) {
                    if (line.startsWith("FILE")) {
                        receiveFile(line);
                    } else if (line.startsWith("MESSAGE")) {
                        broadcastMessage(name + ": " + line.substring(8));
                    }
                }
            } catch (IOException e) {
                System.out.println("Error handling client " + name + ": " + e.getMessage());
            } finally {
                cleanUp();
            }
        }

        private void requestUserInfo() throws IOException {
            while (name == null || nim == null) {
                out.println(name == null ? "SUBMITNAME" : "SUBMITNIM");
                if (name == null) {
                    name = in.readLine();
                } else {
                    nim = in.readLine();
                }
            }
            out.println("NAMEACCEPTED " + name + " " + nim);
            broadcastMessage(name + " (" + nim + ") has joined");
            updateClientList();
        }

        private void receiveFile(String headerLine) throws IOException {
            String[] headerParts = headerLine.split(" ");
            String fileName = headerParts[1];
            long fileSize = Long.parseLong(headerParts[2]);
            byte[] fileBytes = new byte[(int) fileSize];

            InputStream is = socket.getInputStream();
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("server_files/" + fileName));

            int bytesRead, current = 0;
            while (current < fileSize) {
                bytesRead = is.read(fileBytes, current, fileBytes.length - current);
                if (bytesRead >= 0) current += bytesRead;
            }
            bos.write(fileBytes, 0, current);
            bos.flush();
            bos.close();

            broadcastMessage(name + " has sent a file: " + fileName);
        }

        private void broadcastMessage(String message) {
            for (ClientHandler client : clientHandlers) {
                client.out.println("MESSAGE " + message);
            }
        }

        private void updateClientList() {
            StringBuilder userList = new StringBuilder("USERLIST ");
            for (ClientHandler client : clientHandlers) {
                userList.append(client.name).append(",");
            }
            for (ClientHandler client : clientHandlers) {
                client.out.println(userList.toString());
            }
        }

        private void cleanUp() {
            if (name != null) {
                clientHandlers.remove(this);
                broadcastMessage(name + " has left");
                updateClientList();
            }
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Error closing socket for " + name + ": " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 1234;
        new ChatServer(port).start();
    }
}
